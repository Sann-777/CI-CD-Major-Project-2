# StudyNotion Environment Setup Guide

## Overview
This guide provides instructions for setting up the StudyNotion EdTech platform with the updated microservices architecture (payment service removed).

## Service Architecture

### Port Configuration
- **API Gateway**: 3000 (Main entry point)
- **Auth Service**: 3001 (Authentication & authorization)
- **Profile Service**: 3002 (User profiles)
- **Course Service**: 3003 (Course management)
- **Rating Service**: 3005 (Course ratings/reviews)
- **Notification Service**: 3006 (Email notifications)
- **Media Service**: 3007 (File uploads via Cloudinary)
- **Frontend**: 3008 (React TypeScript SPA)

### Database Configuration
- **MongoDB**: Each service uses its own database:
  - `studynotion-auth` (Auth Service)
  - `studynotion-profiles` (Profile Service)
  - `studynotion-courses` (Course Service)
  - `studynotion-ratings` (Rating Service)
  - `studynotion-media` (Media Service)
  - `studynotion-notifications` (Notification Service)

## Environment Setup

### 1. Prerequisites
- Node.js 18+
- MongoDB
- Git

### 2. Clone and Install
```bash
git clone <repository-url>
cd studynotion-edtech-project-main
npm install
```

### 3. Environment Variables
Copy `.env.example` to `.env` in each service directory and update with your credentials:

#### API Gateway (.env)
```env
PORT=3000
NODE_ENV=development
AUTH_SERVICE_URL=http://localhost:3001
PROFILE_SERVICE_URL=http://localhost:3002
COURSE_SERVICE_URL=http://localhost:3003
RATING_SERVICE_URL=http://localhost:3005
NOTIFICATION_SERVICE_URL=http://localhost:3006
MEDIA_SERVICE_URL=http://localhost:3007
FRONTEND_URL=http://localhost:3008
```

#### Auth Service (.env)
```env
PORT=3001
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/studynotion-auth
JWT_SECRET=your_jwt_secret_key_here
MAIL_HOST=smtp.gmail.com
MAIL_USER=your_email@gmail.com
MAIL_PASS=your_app_password_here
FRONTEND_URL=http://localhost:3008
NOTIFICATION_SERVICE_URL=http://localhost:3006
```

#### Profile Service (.env)
```env
PORT=3002
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/studynotion-profiles
FRONTEND_URL=http://localhost:3008
AUTH_SERVICE_URL=http://localhost:3001
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

#### Course Service (.env)
```env
PORT=3003
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/studynotion-courses
AUTH_SERVICE_URL=http://localhost:3001
MEDIA_SERVICE_URL=http://localhost:3007
PROFILE_SERVICE_URL=http://localhost:3002
RATING_SERVICE_URL=http://localhost:3005
FRONTEND_URL=http://localhost:3008
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
```

#### Rating Service (.env)
```env
PORT=3005
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/studynotion-ratings
FRONTEND_URL=http://localhost:3008
AUTH_SERVICE_URL=http://localhost:3001
COURSE_SERVICE_URL=http://localhost:3003
```

#### Notification Service (.env)
```env
PORT=3006
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/studynotion-notifications
MAIL_HOST=smtp.gmail.com
MAIL_USER=your_email@gmail.com
MAIL_PASS=your_app_password_here
FRONTEND_URL=http://localhost:3008
```

#### Media Service (.env)
```env
PORT=3007
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/studynotion-media
FRONTEND_URL=http://localhost:3008
AUTH_SERVICE_URL=http://localhost:3001
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
FOLDER_NAME=StudyNotion
```

#### Frontend (.env)
```env
VITE_BASE_URL=http://localhost:3000
```

## Required External Services

### 1. Email Configuration (Gmail SMTP)
1. Enable 2-factor authentication on your Gmail account
2. Generate an App Password:
   - Go to Google Account settings
   - Security → 2-Step Verification → App passwords
   - Generate password for "Mail"
3. Use this app password in `MAIL_PASS` environment variable

### 2. Cloudinary Setup
1. Create account at [cloudinary.com](https://cloudinary.com)
2. Get your Cloud Name, API Key, and API Secret from dashboard
3. Update environment variables in relevant services

## Running the Application

### Development Mode
```bash
# Start all services
npm run dev

# Or start individual services
cd microservices/api-gateway && npm start
cd microservices/auth-service && npm start
cd microservices/profile-service && npm start
cd microservices/course-service && npm start
cd microservices/rating-service && npm start
cd microservices/notification-service && npm start
cd microservices/media-service && npm start
cd frontend-microservice && npm run dev
```

### Docker Mode
```bash
# Build and start all services
docker-compose up --build

# Start in detached mode
docker-compose up -d --build
```

## Key Changes from Previous Version

### Payment Service Removed
- All payment-related functionality has been removed
- Courses are now free to enroll
- `buyCourse` function replaced with `enrollInCourse`
- Payment endpoints removed from API Gateway

### Port Changes
- API Gateway moved from 4000 to 3000
- All services now use standardized port mapping
- Frontend proxy updated to point to port 3000

### Contact Form Fixed
- Email functionality properly configured in notification service
- SMTP settings validated and enhanced
- Error handling improved

## Troubleshooting

### Common Issues

1. **Service Connection Errors**
   - Ensure all services are running on correct ports
   - Check environment variables are properly set
   - Verify MongoDB is running

2. **Email Not Sending**
   - Verify Gmail SMTP credentials
   - Check app password is correctly generated
   - Ensure 2FA is enabled on Gmail account

3. **File Upload Issues**
   - Verify Cloudinary credentials
   - Check file size limits
   - Ensure proper file types are allowed

4. **Database Connection Issues**
   - Ensure MongoDB is running
   - Check database URIs in environment files
   - Verify database names are unique per service

### Health Checks
- API Gateway: `http://localhost:3000/health`
- Individual services: `http://localhost:[PORT]/health`

## Testing

```bash
# Run all tests
npm test

# Run tests for specific service
cd microservices/[service-name] && npm test
```

## Production Deployment

1. Update all environment variables with production values
2. Use proper secrets management
3. Configure reverse proxy (nginx)
4. Set up SSL certificates
5. Configure monitoring and logging
6. Set up database backups

## Support

For issues or questions, please check:
1. This documentation
2. Service logs for error details
3. Environment variable configuration
4. External service credentials (Gmail, Cloudinary)
