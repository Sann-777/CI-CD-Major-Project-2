# StudyNotion Docker Deployment Guide

## 🚀 Complete Containerization Setup

This guide provides comprehensive instructions for deploying the StudyNotion EdTech platform using Docker containers.

## 📋 Prerequisites

- **Docker**: v20.10+ installed and running
- **Docker Compose**: v2.0+ installed
- **Node.js**: v18+ (for local development)
- **Git**: Latest version

## 🏗️ Architecture Overview

### Containerized Services

| Service | Port | Container Name | Description |
|---------|------|----------------|-------------|
| MongoDB | 27017 | studynotion-mongodb | Database |
| API Gateway | 4000 | studynotion-api-gateway | Main entry point |
| Auth Service | 3001 | studynotion-auth-service | Authentication |
| Course Service | 3003 | studynotion-course-service | Course management |
| Profile Service | 3004 | studynotion-profile-service | User profiles |
| Rating Service | 3005 | studynotion-rating-service | Reviews & ratings |
| Media Service | 3006 | studynotion-media-service | File uploads |
| Notification Service | 3007 | studynotion-notification-service | Email notifications |
| Frontend | 3008 | studynotion-frontend | React application |

## ⚙️ Environment Setup

### 1. Clone and Navigate
```bash
git clone <repository-url>
cd studynotion-edtech-project-main
```

### 2. Environment Configuration
```bash
# Copy environment template
cp .env.example .env

# Edit with your actual values
nano .env
```

### Required Environment Variables
```env
# MongoDB
MONGO_USERNAME=admin
MONGO_PASSWORD=your-secure-password

# JWT
JWT_SECRET=your-super-secret-jwt-key-make-it-long-and-random

# Email (Gmail SMTP)
MAIL_HOST=smtp.gmail.com
MAIL_USER=your-email@gmail.com
MAIL_PASS=your-gmail-app-password

# Cloudinary
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret

```

## 🚀 Deployment Options

### Option 1: Quick Start (Recommended)
```bash
# Use the deployment script
./deploy.sh docker
```

### Option 2: Manual Docker Compose
```bash
# Build and start all services
docker-compose up --build -d

# View logs
docker-compose logs -f

# Check service status
docker-compose ps
```

### Option 3: Individual Service Management
```bash
# Build specific service
docker-compose build auth-service

# Start specific service
docker-compose up auth-service

# Restart specific service
docker-compose restart api-gateway
```

## 📊 Health Monitoring

### Service Health Checks
```bash
# Check all services
curl http://localhost:4000/health

# Check individual services
curl http://localhost:3001/health  # Auth Service
curl http://localhost:3002/health  # Payment Service
curl http://localhost:3003/health  # Course Service
curl http://localhost:3004/health  # Profile Service
curl http://localhost:3005/health  # Rating Service
curl http://localhost:3006/health  # Media Service
curl http://localhost:3007/health  # Notification Service
curl http://localhost:3008/health  # Frontend
```

### Container Status
```bash
# View running containers
docker ps

# View all containers (including stopped)
docker ps -a

# View container logs
docker logs studynotion-api-gateway
docker logs studynotion-auth-service -f
```

## 🔧 Development Workflow

### Local Development with Docker
```bash
# Start development environment
npm run docker:dev

# View logs in real-time
npm run docker:logs

# Restart services
npm run docker:restart
```

### Database Management
```bash
# Connect to MongoDB
docker exec -it studynotion-mongodb mongosh -u admin -p password123

# Backup database
docker exec studynotion-mongodb mongodump --out /backup

# Restore database
docker exec studynotion-mongodb mongorestore /backup
```

## 🛠️ Troubleshooting

### Common Issues

#### 1. Port Conflicts
```bash
# Check what's using a port
lsof -i :4000

# Kill process using port
kill -9 $(lsof -t -i:4000)
```

#### 2. Container Build Failures
```bash
# Clean Docker cache
docker system prune -a

# Rebuild without cache
docker-compose build --no-cache
```

#### 3. Service Connection Issues
```bash
# Check network connectivity
docker network ls
docker network inspect studynotion-network

# Restart networking
docker-compose down
docker-compose up
```

#### 4. Database Connection Problems
```bash
# Check MongoDB logs
docker logs studynotion-mongodb

# Verify MongoDB is accessible
docker exec studynotion-mongodb mongosh --eval "db.adminCommand('ping')"
```

### Debug Mode
```bash
# Run with debug output
DEBUG=* docker-compose up

# Run single service in debug mode
docker-compose run --rm auth-service npm run dev
```

## 📈 Performance Optimization

### Resource Limits
The docker-compose.yml includes resource limits:
- **Memory**: 512MB per microservice
- **CPU**: 0.5 cores per microservice
- **MongoDB**: 1GB memory, 1 CPU core

### Scaling Services
```bash
# Scale specific services
docker-compose up --scale auth-service=3
docker-compose up --scale course-service=2

# Load balance with nginx
docker-compose up --scale api-gateway=2
```

## 🔒 Security Considerations

### Production Deployment
1. **Environment Variables**: Never commit `.env` files
2. **Secrets Management**: Use Docker secrets or external secret managers
3. **Network Security**: Configure proper firewall rules
4. **SSL/TLS**: Use reverse proxy with SSL certificates
5. **User Permissions**: Run containers as non-root users (already configured)

### Security Scanning
```bash
# Scan images for vulnerabilities
docker scout quickview
docker scout cves studynotion-api-gateway
```

## 📦 Backup and Recovery

### Database Backup
```bash
# Create backup
docker exec studynotion-mongodb mongodump --out /backup --gzip

# Schedule automated backups
echo "0 2 * * * docker exec studynotion-mongodb mongodump --out /backup/$(date +%Y%m%d) --gzip" | crontab -
```

### Application Backup
```bash
# Backup volumes
docker run --rm -v studynotion_mongodb_data:/data -v $(pwd):/backup alpine tar czf /backup/mongodb-backup.tar.gz /data
```

## 🚀 Production Deployment

### Docker Swarm (Recommended for Production)
```bash
# Initialize swarm
docker swarm init

# Deploy stack
docker stack deploy -c docker-compose.yml studynotion

# Scale services
docker service scale studynotion_auth-service=3
```

### Kubernetes Alternative
For Kubernetes deployment, use the provided manifests:
```bash
kubectl apply -f kubernetes/
```

## 📞 Support

### Useful Commands
```bash
# Complete cleanup
npm run docker:clean

# Reset everything
docker-compose down -v --rmi all
docker system prune -a

# View resource usage
docker stats

# Export/Import images
docker save studynotion-api-gateway > api-gateway.tar
docker load < api-gateway.tar
```

### Logs and Debugging
```bash
# Aggregate logs
docker-compose logs > studynotion-logs.txt

# Follow specific service logs
docker-compose logs -f --tail=100 auth-service

# Container inspection
docker inspect studynotion-api-gateway
```

## ✅ Verification Checklist

After deployment, verify:
- [ ] All containers are running: `docker ps`
- [ ] Health checks pass: `curl http://localhost:4000/health`
- [ ] Frontend accessible: `http://localhost:3008`
- [ ] API Gateway accessible: `http://localhost:4000`
- [ ] Database connectivity: `docker logs studynotion-mongodb`
- [ ] No error logs: `docker-compose logs | grep -i error`

## 🎯 Next Steps

1. **Monitoring**: Set up Prometheus + Grafana
2. **CI/CD**: Configure Jenkins pipeline
3. **Load Balancing**: Add nginx reverse proxy
4. **SSL**: Configure HTTPS certificates
5. **Backup**: Implement automated backup strategy

---

**🎉 Your StudyNotion platform is now fully containerized and ready for deployment!**

For additional support, check the main README.md or contact the development team.
