import React from 'react'

const EditCourse: React.FC = () => {
  return (
    <>
      <h1 className="mb-14 text-3xl font-medium text-richblack-5">
        Edit Course
      </h1>
      <div className="text-richblack-300">
        Course editing functionality will be implemented here.
      </div>
    </>
  )
}

export default EditCourse
