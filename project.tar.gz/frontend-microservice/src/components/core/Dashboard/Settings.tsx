import React from 'react'

const Settings: React.FC = () => {
  return (
    <>
      <h1 className="mb-14 text-3xl font-medium text-richblack-5">
        Settings
      </h1>
      <div className="text-richblack-300">
        Settings functionality will be implemented here.
      </div>
    </>
  )
}

export default Settings
