import React from 'react'

const AddCourse: React.FC = () => {
  return (
    <>
      <h1 className="mb-14 text-3xl font-medium text-richblack-5">
        Add Course
      </h1>
      <div className="text-richblack-300">
        Course creation functionality will be implemented here.
      </div>
    </>
  )
}

export default AddCourse
